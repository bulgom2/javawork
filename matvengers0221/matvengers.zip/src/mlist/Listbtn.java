package mlist;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class Listbtn {
	
	
	public void gb1(String a, int nx, JPanel c, JButton jb1, JButton jb2, JButton jb3) throws Exception {

		ArrayList<ms> m = new ArrayList<ms>();
		tst t = new tst();
		m = t.result4(a);
		int i = (int)m.size();
		i = i - nx;
		
		if (i >= 3){
			jb1.setText("<html><body><center style='text-align: left'>상호명: " + 
												m.get(0+nx).getName() + "<br><br>별점: "+m.get(0+nx).getStar() +
												"<br><br>주소: "+ m.get(0+nx).getAddr()+"<br><br>전화번호: "+
												m.get(0+nx).getTel() + "</center></body></html>");
			jb1.setFont(new Font("함초롬돋움", Font.PLAIN, 20));
			jb1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
			});
			jb1.setHorizontalAlignment(SwingConstants.LEFT);
			jb1.setBounds(10, 740, 393, 250);
			jb1.setFocusPainted(false);
			c.add(jb1);
			
			jb2.setText("<html><body><center style='text-align: left'>상호명: " + 
												m.get(1+nx).getName() + "<br><br>별점: "+m.get(1+nx).getStar() +
												"<br><br>주소: "+ m.get(1+nx).getAddr()+"<br><br>전화번호: "+
												m.get(1+nx).getTel() + "</center></body></html>");
			jb2.setFont(new Font("함초롬돋움", Font.PLAIN, 20));
			jb2.setHorizontalAlignment(SwingConstants.LEFT);
			jb2.setBounds(403, 740, 393, 250);
			jb2.setFocusPainted(false);
			c.add(jb2);
			
			jb3.setText("<html><body><center style='text-align: left'>상호명: " + 
												m.get(2+nx).getName() + "<br><br>별점: "+m.get(2+nx).getStar() +
												"<br><br>주소: "+ m.get(2+nx).getAddr()+"<br><br>전화번호: "+
												m.get(2+nx).getTel() + "</center></body></html>");
			jb3.setFont(new Font("함초롬돋움", Font.PLAIN, 20));
			jb3.setHorizontalAlignment(SwingConstants.LEFT);
			jb3.setBounds(796, 740, 393, 250);
			jb3.setFocusPainted(false);
			c.add(jb3);

			
			
	}
	else if (i == 2){		
			jb1.setText("<html><body><center style='text-align: left'>상호명: " + 
					m.get(0+nx).getName() + "<br><br>별점: "+m.get(0+nx).getStar() +
					"<br><br>주소: "+ m.get(0+nx).getAddr()+"<br><br>전화번호: "+
					m.get(0+nx).getTel() + "</center></body></html>");
					jb1.setFont(new Font("함초롬돋움", Font.PLAIN, 20));
					jb1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
						}
						});
					jb1.setHorizontalAlignment(SwingConstants.LEFT);
					jb1.setBounds(10, 740, 393, 250);
					jb1.setFocusPainted(false);
					c.add(jb1);
				
					jb2.setText("<html><body><center style='text-align: left'>상호명: " + 
							m.get(1+nx).getName() + "<br><br>별점: "+m.get(1+nx).getStar() +
							"<br><br>주소: "+ m.get(1+nx).getAddr()+"<br><br>전화번호: "+
							m.get(1+nx).getTel() + "</center></body></html>");
					jb2.setFont(new Font("함초롬돋움", Font.PLAIN, 20));
					jb2.setHorizontalAlignment(SwingConstants.LEFT);
					jb2.setBounds(403, 740, 393, 250);
					jb2.setFocusPainted(false);
					c.add(jb2);

		}
	else if(i == 1){
		jb1.setText("<html><body><center style='text-align: left'>상호명: " + 
				m.get(0+nx).getName() + "<br><br>별점: "+m.get(0+nx).getStar() +
				"<br><br>주소: "+ m.get(0+nx).getAddr()+"<br><br>전화번호: "+
				m.get(0+nx).getTel() + "</center></body></html>");
				jb1.setFont(new Font("함초롬돋움", Font.PLAIN, 20));
				jb1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
				});
				jb1.setHorizontalAlignment(SwingConstants.LEFT);
				jb1.setBounds(10, 740, 393, 250);
				jb1.setFocusPainted(false);
				c.add(jb1);

							
		}

	}
	public void sb1(String a, int nx, JButton jb1, JButton jb2, JButton jb3) throws Exception {
		
		ArrayList<ms> m = new ArrayList<ms>();
		tst t = new tst();
		m = t.result4(a);
	int i = (int)m.size();
	i = i - nx;
	if (i < 1) {

	}
	else if (i >= 3){
		jb1.setText("<html><body><center style='text-align: left'>상호명: " + 
				m.get(0+nx).getName() + "<br><br>별점: "+m.get(0+nx).getStar() +
				"<br><br>주소: "+ m.get(0+nx).getAddr()+"<br><br>전화번호: "+
				m.get(0+nx).getTel() + "</center></body></html>");
		jb2.setText("<html><body><center style='text-align: left'>상호명: " + 
				m.get(1+nx).getName() + "<br><br>별점: "+m.get(1+nx).getStar() +
				"<br><br>주소: "+ m.get(1+nx).getAddr()+"<br><br>전화번호: "+
				m.get(1+nx).getTel() + "</center></body></html>");
		jb3.setText("<html><body><center style='text-align: left'>상호명: " + 
											m.get(2+nx).getName() + "<br><br>별점: "+m.get(2+nx).getStar() +
											"<br><br>주소: "+ m.get(2+nx).getAddr()+"<br><br>전화번호: "+
											m.get(2+nx).getTel() + "</center></body></html>");
			
			
	}
	else if (i == 2){		
		jb1.setText("<html><body><center style='text-align: left'>상호명: " + 
				m.get(0+nx).getName() + "<br><br>별점: "+m.get(0+nx).getStar() +
				"<br><br>주소: "+ m.get(0+nx).getAddr()+"<br><br>전화번호: "+
				m.get(0+nx).getTel() + "</center></body></html>");
		jb2.setText("<html><body><center style='text-align: left'>상호명: " + 
				m.get(1+nx).getName() + "<br><br>별점: "+m.get(1+nx).getStar() +
				"<br><br>주소: "+ m.get(1+nx).getAddr()+"<br><br>전화번호: "+
				m.get(1+nx).getTel() + "</center></body></html>");
		jb3.setText("검색 결과 없음");

		}
	else if(i == 1){

							
		jb1.setText("<html><body><center style='text-align: left'>상호명: " + 
				m.get(0+nx).getName() + "<br><br>별점: "+m.get(0+nx).getStar() +
				"<br><br>주소: "+ m.get(0+nx).getAddr()+"<br><br>전화번호: "+
				m.get(0+nx).getTel() + "</center></body></html>");
		jb2.setText("검색 결과 없음");
		jb3.setText("검색 결과 없음");
		}
	}
}
